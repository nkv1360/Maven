package com.kaurn;

import com.rbevans.bookingrate.*;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.POST;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.ws.rs.FormParam;

@Path("calculator")
public class EndPoint {
	@GET	
	@Produces(MediaType.TEXT_HTML)
	public String getText() {
		return "<body> Error. Data was not specified. </body>";
	}
	
	@POST
	@Produces(MediaType.TEXT_HTML)
	@Path("/inputValues")
	public String getParamText(@FormParam("hikes") String hike,
			@FormParam("start") String start,
			@FormParam("duration") String duration, 
			@FormParam("party") String party) {
		String returnString = processInput(hike, start, duration, party);
		return "<body> " + returnString + " </body>";
	}
	
	public String processInput(String hike, String start, String duration, String party) {
		String returnString = "";
		int durationLength = 0;
		int numPeople = 0;
		
		if (hike == null) {
			returnString = "Error. Please select a hike.";
			return returnString;
		} else if (start == null){
			returnString = "Error. Please select a valid start date.";
			return returnString;
		} else if (duration == null){
			returnString = "Error. Please select a duration.";
			return returnString;
		} else {
			//read duration
			try {
				durationLength = Integer.parseInt(duration);
				numPeople = Integer.parseInt(party);
				//calculate rate
				//date formation
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				Date startDate;
				try {
					startDate = sdf.parse(start);
					Calendar c = Calendar.getInstance();
					c.setTime(startDate);
					c.add(Calendar.DATE, durationLength - 1);
					String stringEndDate = sdf.format(c.getTime());
					try {
						int startYear = Integer.parseInt(start.substring(6,10));
						int startMonth = Integer.parseInt(start.substring(0,2));
						int startDay = Integer.parseInt(start.substring(3,5));
						BookingDay startBookingDay = new BookingDay(startYear, startMonth, startDay);
						int endYear = Integer.parseInt(stringEndDate.substring(6,10));
						int endMonth = Integer.parseInt(stringEndDate.substring(0,2));
						int endDay = Integer.parseInt(stringEndDate.substring(3,5));
						BookingDay endBookingDay = new BookingDay(endYear, endMonth, endDay);
						System.out.println("Starting Date: " + startBookingDay);
						
						if (!startBookingDay.isValidDate()) {
							returnString = "Error. Start Date is invalid.";
							return returnString;
						} else if (!endBookingDay.isValidDate()) {
							returnString = "Error. End Date is invalid.";
							return returnString;
						} else {
							//Find rates
							Rates rates = null;
							if (hike.equals("beaten")) {
								rates = new Rates(com.rbevans.bookingrate.Rates.HIKE.BEATEN);
							} else if (hike.equals("hellroaring")) {
								rates = new Rates(com.rbevans.bookingrate.Rates.HIKE.HELLROARING);
							} else if (hike.equals("gardiner")){
								rates = new Rates(com.rbevans.bookingrate.Rates.HIKE.GARDINER);
							}
							if (rates != null) {
								rates.setBeginDate(startBookingDay);
						        rates.setDuration(durationLength);
						        System.out.println("Are the dates valid? " + rates.isValidDates());
						        if (rates.isValidDates()) {
						            System.out.println("Total Cost of Trip: $" + rates.getCost());
						            System.out.println("# of Weekdays: " + rates.getNormalDays());
						            System.out.println("# of Weekends: " + rates.getPremiumDays());  
						            if(rates.getCost() != -0.01) {
						            	
						            	// check party number
						            	if ((0 < numPeople) && (numPeople < 11)) {
						            		double totalRate = numPeople * rates.getCost();
						            		returnString = hike + " hike for " + duration + " days starting on " + start + " for " + party + " people will cost $" + Double.toString(totalRate);
							            	return returnString;
						            	} 
						            	
						            	else {
						            		//number of ppl in party is wrong
						            		returnString = "Error: The number of people in the party must be between 1 and 10.";
						        			return returnString;
						            	}
						            } 
						            
						            else {
						            	//rate error
										returnString = "Error: " + rates.getDetails();
										return returnString;
						            }
						        } 
						        
						        else {
						        	//invalid dates
						        	returnString = "Error: Invalid dates were selected. Please select dates within the season. " + rates.getDetails();
									return returnString;
						        }
							} 
							
							else {
								//no hike selection made
								returnString = "Error: No hike selection was made. Please select a hike. Please retry.";
								return returnString;
							}
						}	
					} 
					
					catch (NumberFormatException nfe) {
						//parsing error
						returnString = "Error: Incorrect date format was entered. Must be MM/DD/YYYY. Please retry.";
						return returnString;
					} 
					
					catch (StringIndexOutOfBoundsException e) {
						//date out of bounds
						returnString = "Error: Incorrect date format was entered. Must be MM/DD/YYYY. Please retry.";
						return returnString;
					}
				} 
				
				catch (ParseException e) {
					//parsing error
					returnString = "Error: Incorrect date format was entered. Must be MM/DD/YYYY. Please retry.";
					return returnString;
				}
			} 
			
			catch (NumberFormatException nfe) {
				//error parsing the duration
				returnString = "Error: Duration or party must be entered as integers. Please retry.";
				return returnString;
			}
		}
	}
}
